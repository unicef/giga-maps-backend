from django.apps import AppConfig


class ProcoDataMigrationsConfig(AppConfig):
    name = 'proco_data_migrations'
