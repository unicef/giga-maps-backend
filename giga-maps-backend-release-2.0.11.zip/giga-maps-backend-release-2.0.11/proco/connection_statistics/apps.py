from django.apps import AppConfig


class ConnectionStatisticsConfig(AppConfig):
    name = 'proco.connection_statistics'
    verbose_name = 'Connection Statistics'
