default_app_config = 'proco.connection_statistics.apps.ConnectionStatisticsConfig'
