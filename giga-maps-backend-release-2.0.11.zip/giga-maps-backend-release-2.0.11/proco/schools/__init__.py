default_app_config = 'proco.schools.apps.SchoolsConfig'
