error_mess_retrive = {
    "error_mess": "Error in record Fetch"
}
id_missing_error_mess = {
    "error_mess": "Missing Query Parameter ID"
}
delete_error_mess = {
    "error_mess": "Error in record Delete"
}
delete_succ_mess = {
    "succ_mess": "Record Deleted"
}
error_mess = {
    "error_mess": "Something Wrong"
}
error_mess_for_record_exist = {
    "error_mess": "You can not add more than one record."
}
